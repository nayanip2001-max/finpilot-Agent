"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Activity,
  AlertTriangle,
  Brain,
  ChevronRight,
  CircleDot,
  Gauge,
  ShieldAlert,
  Sparkles,
  TrendingUp,
  UserRound,
  Zap,
} from "lucide-react";

type Agent = {
  signal?: string;
  confidence?: number;
  status?: string;
  reasons?: string[];
};

type Analysis = {
  symbol?: string;
  recommendation?: string;
  confidence?: number;
  summary?: string;
  reasons?: string[];
  risks?: string[];
  what_would_change_decision?: string[];
  degraded?: boolean;
  latency_ms?: number;
  agent_consensus?: Record<string, Agent>;
  agents?: Record<string, Agent & { metrics?: { narration?: string } }>;
  reasoning_trace?: {
    step: number;
    agent: string;
    decision: string;
    confidence?: number | null;
    reason: string;
  }[];
};

type User = {
  id: string;
  name: string;
  risk_profile: string;
  investment_horizon?: string;
};

const STOCKS = ["RELIANCE", "TCS", "HDFCBANK", "INFY", "ICICIBANK"];

const fallbackUsers: User[] = [
  { id: "user_001", name: "Priya", risk_profile: "CONSERVATIVE", investment_horizon: "LONG" },
  { id: "user_002", name: "Arjun", risk_profile: "MODERATE", investment_horizon: "MEDIUM" },
  { id: "user_003", name: "Karthik", risk_profile: "AGGRESSIVE", investment_horizon: "LONG" },
];

const agents = [
  ["technical", "TECHNICAL", TrendingUp],
  ["fundamental", "FUNDAMENTAL / RAG", Brain],
  ["sentiment", "SENTIMENT", Activity],
  ["risk", "RISK", ShieldAlert],
] as const;

export default function Home() {
  const [users, setUsers] = useState<User[]>(fallbackUsers);
  const [userId, setUserId] = useState("user_001");
  const [symbol, setSymbol] = useState("RELIANCE");
  const [question, setQuestion] = useState("Should I increase my position?");
  const [result, setResult] = useState<Analysis | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [activeAgent, setActiveAgent] = useState(-1);

  useEffect(() => {
    fetch("/api/users")
      .then((r) => r.json())
      .then((d) => d.users?.length && setUsers(d.users))
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (!loading) {
      setActiveAgent(-1);
      return;
    }
    setActiveAgent(0);
    const timer = window.setInterval(() => {
      setActiveAgent((x) => (x + 1) % agents.length);
    }, 650);
    return () => window.clearInterval(timer);
  }, [loading]);

  async function analyze() {
    setLoading(true);
    setResult(null);
    setError("");
    try {
      const r = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ user_id: userId, symbol, question }),
      });
      const data = await r.json();
      if (!r.ok) throw new Error(data.detail || "Analysis failed");
      setResult(data);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Analysis failed");
    } finally {
      setLoading(false);
    }
  }

  const user = users.find((u) => u.id === userId) || users[0];
  const recommendation = result?.recommendation?.toUpperCase() || "";
  const finalConfidence = Math.round((result?.confidence || 0) * 100);

  function getAgent(key: string) {
    return result?.agent_consensus?.[key] || result?.agents?.[key];
  }

  function signalClass(signal?: string) {
    if (!signal) return "neutral";
    if (/BULLISH|POSITIVE|ROOM_TO_ADD/i.test(signal)) return "positive";
    if (/BEARISH|NEGATIVE|OVER_CONCENTRATED/i.test(signal)) return "danger";
    return "neutral";
  }

  const narration = result?.agents?.synthesis?.metrics?.narration;

  return (
    <main className="app-shell">
      <div className="city-glow" />
      <div className="web web-a" />
      <div className="web web-b" />

      <header className="topbar">
        <div className="brand-wrap">
          <div className="spider-mark">🕷</div>
          <div>
            <div className="brand">FINPILOT <span>AI</span></div>
            <div className="tagline">YOUR FRIENDLY NEIGHBORHOOD INVESTMENT COPILOT</div>
          </div>
        </div>
        <div className="hud-status"><i /> SPIDER-SENSE ONLINE</div>
      </header>

      <section className="hero">
        <div>
          <div className="eyebrow"><Zap size={13} /> MULTI-AGENT FINANCIAL INTELLIGENCE</div>
          <h1>With great power<br /><span>comes great insight.</span></h1>
          <p>Market signals are only the beginning. FinPilot connects evidence, sentiment and portfolio risk to make the decision personal.</p>
        </div>
        <div className="hero-orb">
          <div className="orbit orbit-1" />
          <div className="orbit orbit-2" />
          <div className="orb-core">🕷</div>
        </div>
      </section>

      <section className="workspace">
        <aside className="glass-panel control-panel">
          <div className="panel-kicker">MISSION CONTROL</div>
          <h2>Analyze a Position</h2>

          <label><UserRound size={13} /> INVESTOR</label>
          <select value={userId} onChange={(e) => { setUserId(e.target.value); setResult(null); }}>
            {users.map((u) => <option key={u.id} value={u.id}>{u.name} — {u.risk_profile}</option>)}
          </select>

          <div className="profile-mini">
            <div className="avatar">{user.name[0]}</div>
            <div><strong>{user.name}</strong><span>{user.risk_profile} RISK • {user.investment_horizon || "LONG"} HORIZON</span></div>
          </div>

          <label><TrendingUp size={13} /> TARGET ASSET</label>
          <select value={symbol} onChange={(e) => { setSymbol(e.target.value); setResult(null); }}>
            {STOCKS.map((s) => <option key={s}>{s}</option>)}
          </select>

          <label><Sparkles size={13} /> ASK FINPILOT</label>
          <textarea value={question} onChange={(e) => setQuestion(e.target.value)} />

          <button className="analyze-btn" onClick={analyze} disabled={loading}>
            {loading ? <><span className="loader" /> SPIDER-SENSE SCANNING...</> : <>RUN AI ANALYSIS <ChevronRight size={18} /></>}
          </button>

          <div className="pipeline">
            <div className="panel-kicker">AGENT NETWORK</div>
            {agents.map(([key, name], i) => (
              <div className={`pipeline-row ${loading && activeAgent === i ? "active" : ""}`} key={key}>
                <span className="node" /><span>{name}</span><span className="line" /><CircleDot size={11} />
              </div>
            ))}
          </div>
        </aside>

        <section className="glass-panel result-panel">
          {!result && !loading && (
            <div className="empty">
              <div className="empty-spider">🕷</div>
              <div className="panel-kicker">SPIDER-SENSE STANDBY</div>
              <h2>Ready to connect the dots.</h2>
              <p>Choose an investor, select a stock and ask your question. The agent web will analyze the decision.</p>
              <div className="empty-chips"><span>TECHNICAL</span><b>×</b><span>RAG</span><b>×</b><span>SENTIMENT</span><b>×</b><span>RISK</span></div>
            </div>
          )}

          {loading && (
            <div className="empty">
              <div className="scan-ring"><div className="scan-core">🕷</div></div>
              <div className="panel-kicker">SPIDER-SENSE ACTIVE</div>
              <h2>Agents are connecting...</h2>
              <p>Scanning signals, evidence, sentiment and portfolio risk.</p>
            </div>
          )}

          {result && (
            <div className="analysis">
              <div className="decision-head">
                <div>
                  <div className="eyebrow"><Gauge size={13} /> {result.symbol || symbol} • {user.name}</div>
                  <h2>Investment Decision</h2>
                  <small>{result.latency_ms ?? "—"} ms analysis {result.degraded && <b className="degraded">DEGRADED DATA</b>}</small>
                </div>
                <div className={`decision ${recommendation.toLowerCase()}`}>{recommendation || "HOLD"}</div>
              </div>

              <div className="confidence">
                <div><span>FINAL CONFIDENCE</span><strong>{finalConfidence}%</strong></div>
                <div className="confidence-track"><div style={{ width: `${finalConfidence}%` }} /></div>
              </div>

              <div className="section">
                <div className="section-title"><Sparkles size={14} /> SYNTHESIS AGENT NARRATION</div>
                <div className="narration">
                  {narration || result.summary || result.reasons?.[0] || "The Synthesis Agent combined the available signals and portfolio context."}
                </div>
              </div>

              <div className="section">
                <div className="section-title"><span className="web-icon">✦</span> AGENT WEB</div>
                <div className="agent-grid">
                  {agents.map(([key, name, Icon], i) => {
                    const a = getAgent(key);
                    return (
                      <div className={`agent-card ${signalClass(a?.signal)}`} key={key}>
                        <div className="agent-icon"><Icon size={16} /></div>
                        <div className="agent-name">{name}</div>
                        <div className="agent-signal">{a?.signal || "UNKNOWN"}</div>
                        <div className="agent-bar"><div style={{ width: `${(a?.confidence || 0) * 100}%` }} /></div>
                        <small>{Math.round((a?.confidence || 0) * 100)}% CONFIDENCE</small>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="two-col">
                <div className="section">
                  <div className="section-title"><span>✓</span> WHY THIS DECISION</div>
                  <div className="list-card">
                    {(result.reasons || []).map((x, i) => <div className="list-item" key={i}><b>✓</b><span>{x}</span></div>)}
                  </div>
                </div>
                <div className="section">
                  <div className="section-title warning"><AlertTriangle size={14} /> RISKS</div>
                  <div className="risk-card">
                    {(result.risks?.length ? result.risks : ["No additional risks were returned."]).map((x, i) => <div key={i}>⚠ {x}</div>)}
                  </div>
                </div>
              </div>

              {result.what_would_change_decision?.length ? (
                <div className="section">
                  <div className="section-title">↻ WHAT WOULD CHANGE THE DECISION?</div>
                  <div className="change-card">{result.what_would_change_decision.map((x, i) => <div key={i}>{x}</div>)}</div>
                </div>
              ) : null}

              {result.reasoning_trace?.length ? (
                <div className="section">
                  <div className="section-title">◎ DECISION TRACE</div>
                  <div className="trace">
                    {result.reasoning_trace.map((s) => (
                      <div className="trace-row" key={s.step}>
                        <b>{s.step}</b><span>{s.agent}</span><strong>{s.decision}</strong><em>{s.reason}</em>
                      </div>
                    ))}
                  </div>
                </div>
              ) : null}

              <div className="disclaimer">
                <ShieldAlert size={13} /> SYNTHETIC DEMO DATA • NOT FINANCIAL ADVICE • Missing evidence is explicitly degraded rather than fabricated.
              </div>
            </div>
          )}
        </section>
      </section>

      <footer>
        <span>🕷 FINPILOT AI</span>
        <span>TECHNICAL • RAG • SENTIMENT • RISK • SYNTHESIS</span>
      </footer>

      {error && <div className="toast"><AlertTriangle size={16} /> {error}</div>}
    </main>
  );
}
