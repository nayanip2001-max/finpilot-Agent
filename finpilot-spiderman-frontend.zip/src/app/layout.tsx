import "./globals.css";

export const metadata = {
  title: "FinPilot AI — Spider-Sense Investment Copilot",
  description: "Risk-aware multi-agent investment research dashboard",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
